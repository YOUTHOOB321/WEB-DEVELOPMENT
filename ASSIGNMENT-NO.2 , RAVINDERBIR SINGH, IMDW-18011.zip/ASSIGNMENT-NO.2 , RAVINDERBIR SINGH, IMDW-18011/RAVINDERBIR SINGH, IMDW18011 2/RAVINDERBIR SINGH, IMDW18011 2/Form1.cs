﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RAVINDERBIR_SINGH__IMDW18011_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string grum, blum, pluk, lrid;

                grum = textBox1.Text;
                blum = textBox2.Text;
                pluk = textBox3.Text;
                lrid = textBox4.Text;

                double G, B, P, L, KF, LP, PU, FK;

                G = double.Parse(blum);
                B = double.Parse(blum);
                P = double.Parse(pluk);
                L = double.Parse(lrid);


                KF = 3.14159;


                LP = (4.0 / 3) * KF * G * G * G;

                PU = (KF) * (G * G) * (B);

                FK = P * L * B;

                if (radioButton1.Checked)
                {
                    label6.Text = LP.ToString();
                    textBox2.Text = (".");
                    textBox3.Text = (".");
                    textBox4.Text = (".");
                }
                else if (radioButton2.Checked)
                {
                    label6.Text = FK.ToString();
                    textBox3.Text = (".");
                    textBox4.Text = (".");

                }
                else if (radioButton3.Checked)
                {
                    label6.Text = FK.ToString();
                    textBox1.Text = (".");
                }

            }
            catch
            {
                MessageBox.Show("Enter full Values");
            }
        }
    }
}
